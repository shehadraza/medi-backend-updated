
"""Policy-constrained MedlinePlus synchronization with bounded I/O and versioning."""
from __future__ import annotations

import asyncio
import hashlib
import re
import uuid
import xml.etree.ElementTree as ET
import time
from datetime import date, datetime, timedelta, timezone
from html.parser import HTMLParser
from urllib.parse import urlparse

import httpx
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.ai import KnowledgeChunk, KnowledgeDocument, KnowledgeSource, KnowledgeSyncState
# Register the users table in the shared SQLAlchemy metadata.
from app.models.user import User  # noqa: F401
from app.modules.ai.rag.ingestion import ingest_document
from app.modules.ai.embeddings.factory import get_embedding_provider
from app.modules.ai.rag.chunking import normalize_text
from app.modules.ai.source_policy import (
    PUBMED_ACQUISITION_ENABLED, PUBMED_SOURCE_NAME, PUBMED_SOURCE_URL,
)

MEDLINE_API = "https://wsearch.nlm.nih.gov/ws/query"
SOURCE_URL = "https://medlineplus.gov/about/developers/webservices/"
TRUSTED_HOSTS = {"medlineplus.gov", "www.medlineplus.gov"}
QUERIES = ("medications", "heart diseases", "diabetes", "asthma", "pregnancy")
MAX_RESPONSE_BYTES = 5_000_000


class _TextOnly(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts: list[str] = []

    def handle_data(self, data: str) -> None:
        self.parts.append(data)


def _trusted_document_url(url: str) -> bool:
    try:
        parsed = urlparse(url)
        return (
            parsed.scheme == "https"
            and parsed.hostname is not None
            and parsed.hostname.casefold() in TRUSTED_HOSTS
            and parsed.username is None
            and parsed.password is None
        )
    except (TypeError, ValueError):
        return False


def parse_medlineplus_xml(body: bytes) -> list[dict[str, str]]:
    """Parse official MedlinePlus healthTopic XML records."""
    if len(body) > MAX_RESPONSE_BYTES:
        raise ValueError("source_payload_too_large")

    if re.search(rb"<!\s*(DOCTYPE|ENTITY)\b", body, flags=re.IGNORECASE):
        raise ValueError("source_payload_declarations_forbidden")

    try:
        root = ET.fromstring(body)
    except ET.ParseError as exc:
        raise ValueError("invalid_source_payload") from exc

    records: list[dict[str, str]] = []

    for node in root.findall(".//document")[:10]:
        url = node.attrib.get("url", "").strip()

        if not _trusted_document_url(url):
            continue

        parsed_url = urlparse(url)
        slug = parsed_url.path.rstrip("/").split("/")[-1]
        slug = re.sub(r"\.html?$", "", slug, flags=re.IGNORECASE)

        title = (
            node.attrib.get("title", "").strip()
            or re.sub(r"[-_]+", " ", slug).strip().title()
            or "MedlinePlus Health Topic"
        )

        content_parts: list[str] = []

        for item in node.findall("content"):
            content_name = item.attrib.get("name", "").casefold()

            if content_name not in {
                "healthtopic",
                "fullsummary",
                "snippet",
            }:
                continue

            raw_content = "".join(item.itertext())

            parser = _TextOnly()
            parser.feed(raw_content)
            parser.close()

            parts = [
                re.sub(r"\s+", " ", part).strip()
                for part in parser.parts
            ]

            parts = [part for part in parts if part]
            content_parts.extend(parts)

            # Prefer a short, descriptive heading/title from the source.
            for candidate in parts:
                if candidate.casefold() in {"drugs"}:
                    continue

                if re.fullmatch(r"[A-Z0-9]{2,6}", candidate):
                    continue

                if len(candidate) > 80:
                    continue

                if re.search(r"[.!?]", candidate):
                    continue

                title = candidate
                break

        text_content = normalize_text(
            re.sub(r"\s+", " ", " ".join(content_parts))
        )[:100_000]

        if title and len(text_content) >= 80:
            records.append({
                "title": title[:500],
                "url": url,
                "text": text_content,
                "language": "en",
                "updated": node.attrib.get("date", "")[:32],
                "publication_date": node.attrib.get("date", "")[:64],
                "source_type": "government_health_topic",
            })

    return records


async def _read_limited_response(response: httpx.Response) -> bytes:
    chunks: list[bytes] = []
    size = 0

    async for chunk in response.aiter_bytes():
        size += len(chunk)

        if size > MAX_RESPONSE_BYTES:
            raise ValueError("source_payload_too_large")

        chunks.append(chunk)

    return b"".join(chunks)


async def fetch_medlineplus(
    client: httpx.AsyncClient,
    query: str,
) -> list[dict[str, str]]:
    async with client.stream(
        "GET",
        MEDLINE_API,
        params={
            "db": "healthTopics",
            "term": query,
            "retmax": 10,
            "rettype": "topic",
        },
    ) as response:
        response.raise_for_status()
        body = await _read_limited_response(response)

    return parse_medlineplus_xml(body)


async def _ensure_source_and_attempt(
    db: AsyncSession,
    now: datetime,
    *,
    name: str = "MedlinePlus Web Service",
    source_url: str = SOURCE_URL,
    publisher: str = "U.S. National Library of Medicine",
    source_reference: str = (
        "Official Web Service; attribution required. "
        "https://medlineplus.gov/about/using/usingcontent/"
    ),
) -> str | None:
    lock_key = "medi:knowledge:" + source_url

    await db.execute(
        text("SELECT pg_advisory_xact_lock(hashtextextended(:key, 0))"),
        {"key": lock_key},
    )

    result = await db.execute(
        select(KnowledgeSource).where(
            KnowledgeSource.name == name,
            KnowledgeSource.source_url == source_url,
        ).with_for_update()
    )

    source = result.scalar_one_or_none()

    if source is None:
        source = KnowledgeSource(
            name=name,
            publisher=publisher,
            source_url=source_url,
            source_reference=source_reference,
            review_status="approved",
        )
        db.add(source)
        await db.flush()
    else:
        source.review_status = "approved"

    source_id = str(source.id)

    state = await db.get(KnowledgeSyncState, source_id)

    if state is None:
        state = KnowledgeSyncState(source_id=source_id)
        db.add(state)

    if state.next_sync_at is not None and state.next_sync_at > now:
        await db.rollback()
        return None

    state.last_attempt_at = now
    state.next_sync_at = now + timedelta(
        seconds=min(
            settings.AI_KNOWLEDGE_SYNC_INTERVAL_HOURS * 3600,
            settings.AI_KNOWLEDGE_SYNC_TIMEOUT_SECONDS * (len(QUERIES) + 1),
        )
    )
    state.last_error_code = None

    await db.commit()

    return source_id


async def _record_failure(
    db: AsyncSession,
    source_id: str,
    now: datetime,
) -> None:
    """Persist sanitized failure state by stable ID after rolling back work."""
    await db.rollback()

    state = await db.get(KnowledgeSyncState, source_id)

    if state is None:
        state = KnowledgeSyncState(source_id=source_id)
        db.add(state)

    failures = int(state.failure_count or 0) + 1

    retry_seconds = min(
        settings.AI_KNOWLEDGE_SYNC_INTERVAL_HOURS * 3600,
        settings.AI_KNOWLEDGE_SYNC_RETRY_SECONDS
        * (2 ** min(failures - 1, 10)),
    )

    state.failure_count = failures
    state.last_attempt_at = now
    state.next_sync_at = now + timedelta(seconds=retry_seconds)
    state.last_error_code = "source_sync_failed"

    await db.commit()


def _source_date(record: dict[str, str]) -> datetime | None:
    try:
        return datetime.combine(
            date.fromisoformat(record["updated"]),
            datetime.min.time(),
            timezone.utc,
        )
    except (KeyError, ValueError, TypeError):
        return None


def _append_metadata_history(
    document: KnowledgeDocument,
    snapshot: dict,
) -> None:
    history = list(document.metadata_history or [])
    history.append(snapshot)
    document.metadata_history = history


async def _apply_records(
    db: AsyncSession,
    source_id: str,
    records: list[dict[str, str]],
    now: datetime,
) -> dict[str, int]:
    locked = await db.execute(
        select(KnowledgeSource)
        .where(KnowledgeSource.id == source_id)
        .with_for_update()
    )

    source = locked.scalar_one_or_none()

    if source is None:
        raise ValueError("trusted_source_missing")

    source_name = getattr(source, "name", "MedlinePlus Web Service")
    source_publisher = getattr(
        source,
        "publisher",
        "U.S. National Library of Medicine",
    )

    if source_name == PUBMED_SOURCE_NAME and not PUBMED_ACQUISITION_ENABLED:
        await db.rollback()
        return {
            "seen": 0,
            "created": 0,
            "unchanged": 0,
            "metadata_updated": 0,
            "out_of_order": 0,
            "skipped": 1,
            "disabled": 1,
        }

    embedding_provider = get_embedding_provider()
    state = await db.get(KnowledgeSyncState, source_id)

    counts = {
        "seen": 0,
        "created": 0,
        "unchanged": 0,
        "metadata_updated": 0,
        "out_of_order": 0,
    }

    for record in records:
        parsed_url = urlparse(record.get("url", ""))

        allowed_host = (
            parsed_url.hostname in TRUSTED_HOSTS
            if source_name == "MedlinePlus Web Service"
            else parsed_url.hostname == "pubmed.ncbi.nlm.nih.gov"
        )

        if (
            parsed_url.scheme != "https"
            or not allowed_host
            or parsed_url.username
            or parsed_url.password
        ):
            counts["rejected"] = counts.get("rejected", 0) + 1
            continue

        counts["seen"] += 1

        normalized = normalize_text(record["text"])
        digest = hashlib.sha256(
            normalized.encode("utf-8")
        ).hexdigest()

        source_updated_at = _source_date(record)

        source_metadata = {
            "source_type": str(
                record.get("source_type", "medical_reference")
            )[:80],
            "publication_date": str(
                record.get("publication_date", "")
            )[:64] or None,
            "retrieved_at": now.isoformat(),
            "external_id": str(
                record.get("external_id", "")
            )[:120] or None,
            "language": str(
                record.get("language", "und")
            )[:16],
            "publisher": source_publisher,
            "source_url": record["url"],
            "section_labels": [
                str(item)[:80]
                for item in record.get("section_labels", [])[:20]
            ],
            "topic_terms": [
                str(item)[:160]
                for item in record.get("topic_terms", [])[:50]
            ],
            "publication_types": [
                str(item)[:120]
                for item in record.get("publication_types", [])[:20]
            ],
        }

        same_result = await db.execute(
            select(KnowledgeDocument)
            .where(
                KnowledgeDocument.source_id == source_id,
                KnowledgeDocument.content_hash == digest,
            )
            .with_for_update()
        )

        same = same_result.scalar_one_or_none()

        if same is not None:
            if same.source_url == record["url"] and same.status != "published":
                active_result = await db.execute(
                    select(KnowledgeDocument)
                    .where(
                        KnowledgeDocument.source_id == source_id,
                        KnowledgeDocument.source_url == record["url"],
                        KnowledgeDocument.status == "published",
                    )
                    .order_by(KnowledgeDocument.version.desc())
                    .limit(1)
                    .with_for_update()
                )

                active = active_result.scalar_one_or_none()

                if (
                    active is not None
                    and source_updated_at is not None
                    and active.source_updated_at is not None
                    and source_updated_at < active.source_updated_at
                ):
                    active.last_seen_at = now
                    counts["out_of_order"] += 1
                    continue

                if active is not None and active.id != same.id:
                    active.status = "archived"
                    next_version = active.version + 1
                else:
                    next_version = same.version + 1

                _append_metadata_history(
                    same,
                    {
                        "version": same.version,
                        "title": same.title,
                        "source_updated_at": (
                            same.source_updated_at.isoformat()
                            if same.source_updated_at
                            else None
                        ),
                        "source_url": same.source_url,
                        "content_hash": same.content_hash,
                        "status": same.status,
                        "observed_at": now.isoformat(),
                    },
                )

                same.version = next_version
                same.title = record["title"]
                same.source_updated_at = source_updated_at
                same.source_metadata = source_metadata
                same.last_seen_at = now
                same.status = "draft"

                await db.flush()

                await ingest_document(
                    db,
                    same,
                    normalized.encode("utf-8"),
                    "document.txt",
                 embedding_provider=embedding_provider,
                )

                same.status = "published"
                same.published_at = now
                counts["created"] += 1
                continue

            old_metadata = dict(same.source_metadata or {})
            old_metadata.pop("retrieved_at", None)

            stable_metadata = dict(source_metadata)
            stable_metadata.pop("retrieved_at", None)

            metadata_changed = (
                same.title != record["title"]
                or (
                    source_updated_at is not None
                    and same.source_updated_at != source_updated_at
                )
                or (
                    same.source_metadata is not None
                    and old_metadata != stable_metadata
                )
            )

            if same.source_url == record["url"] and metadata_changed:
                _append_metadata_history(
                    same,
                    {
                        "version": same.version,
                        "title": same.title,
                        "source_updated_at": (
                            same.source_updated_at.isoformat()
                            if same.source_updated_at
                            else None
                        ),
                        "source_url": same.source_url,
                        "content_hash": same.content_hash,
                        "source_metadata": same.source_metadata,
                        "observed_at": now.isoformat(),
                    },
                )

                same.version += 1
                same.title = record["title"]

                if source_updated_at is not None:
                    same.source_updated_at = source_updated_at

                same.last_seen_at = now
                same.source_metadata = source_metadata
                counts["metadata_updated"] += 1

            else:
                same.last_seen_at = now
                same.source_metadata = source_metadata
                counts["unchanged"] += 1

            continue

        prior_result = await db.execute(
            select(KnowledgeDocument)
            .where(
                KnowledgeDocument.source_id == source_id,
                KnowledgeDocument.source_url == record["url"],
                KnowledgeDocument.status == "published",
            )
            .order_by(KnowledgeDocument.version.desc())
            .limit(1)
            .with_for_update()
        )

        prior = prior_result.scalar_one_or_none()

        if (
            prior is not None
            and source_updated_at is not None
            and prior.source_updated_at is not None
            and source_updated_at < prior.source_updated_at
        ):
            prior.last_seen_at = now
            counts["out_of_order"] += 1
            continue

        version = prior.version + 1 if prior else 1

        if prior:
            prior.status = "archived"

        document = KnowledgeDocument(
            id=str(uuid.uuid4()),
            source_id=source_id,
            title=record["title"],
            language=record["language"],
            version=version,
            content_hash=digest,
            status="draft",
            source_url=record["url"],
            source_updated_at=source_updated_at,
            source_metadata=source_metadata,
            last_seen_at=now,
        )

        db.add(document)
        await db.flush()

        await ingest_document(
            db,
            document,
            normalized.encode("utf-8"),
            "document.txt",
        )

        if document.status != "ready":
            raise ValueError("source_document_invalid")

        document.status = "published"
        document.published_at = now
        counts["created"] += 1

    if state is not None:
        state.last_success_at = now
        state.last_attempt_at = now
        state.next_sync_at = now + timedelta(
            hours=settings.AI_KNOWLEDGE_SYNC_INTERVAL_HOURS
        )
        state.last_error_code = None
        state.failure_count = 0
        state.documents_seen = counts["seen"]

    await db.commit()

    return counts


async def sync_medlineplus(
    db: AsyncSession,
    *,
    client: httpx.AsyncClient | None = None,
) -> dict[str, int]:
    now = datetime.now(timezone.utc)

    source_id = await _ensure_source_and_attempt(db, now)

    if source_id is None:
        return {
            "seen": 0,
            "created": 0,
            "unchanged": 0,
            "metadata_updated": 0,
            "out_of_order": 0,
            "skipped": 1,
        }

    owns_client = client is None

    client = client or httpx.AsyncClient(
        timeout=settings.AI_KNOWLEDGE_SYNC_TIMEOUT_SECONDS,
        follow_redirects=False,
        headers={"User-Agent": "MEDI-Knowledge-Sync/1.0"},
    )

    try:
        records_by_url: dict[str, dict[str, str]] = {}

        for query in QUERIES:
            for record in await fetch_medlineplus(client, query):
                records_by_url[record["url"]] = record

        return await _apply_records(
            db,
            source_id,
            list(records_by_url.values()),
            now,
        )

    except Exception:
        await _record_failure(
            db,
            source_id,
            datetime.now(timezone.utc),
        )
        raise

    finally:
        if owns_client:
            await client.aclose()


# PubMed adapter: official NCBI E-utilities, bounded to a small set of configured
# searches and abstract metadata. No full-text harvesting or website scraping.
PUBMED_API = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
PUBMED_QUERIES = (
    "diabetes[Title/Abstract]",
    "asthma[Title/Abstract]",
    "headache[Title/Abstract]",
)
NCBI_HOST = "eutils.ncbi.nlm.nih.gov"
PUBMED_MAX_RECORDS = 8
_ncbi_request_lock = asyncio.Lock()
_ncbi_last_request = 0.0


def _parse_pubmed_xml(body: bytes) -> list[dict[str, str]]:
    if len(body) > MAX_RESPONSE_BYTES:
        raise ValueError("source_payload_too_large")

    if re.search(rb"<!\s*(DOCTYPE|ENTITY)\b", body, flags=re.IGNORECASE):
        raise ValueError("source_payload_declarations_forbidden")

    try:
        root = ET.fromstring(body)
    except ET.ParseError as exc:
        raise ValueError("invalid_source_payload") from exc

    rows: list[dict[str, str]] = []

    for article in root.findall(".//PubmedArticle")[:PUBMED_MAX_RECORDS]:
        pmid = (article.findtext(".//PMID") or "").strip()

        title_node = article.find(".//ArticleTitle")
        title = (
            " ".join("".join(title_node.itertext()).split())
            if title_node is not None
            else ""
        )

        abstract_parts = []
        section_labels = []

        for part in article.findall(".//Abstract/AbstractText"):
            label = (
                part.attrib.get("Label")
                or part.attrib.get("NlmCategory")
                or ""
            ).strip()

            if label:
                section_labels.append(label[:80])

            text_part = " ".join("".join(part.itertext()).split())

            abstract_parts.append(
                f"{label}: {text_part}" if label else text_part
            )

        abstract = " ".join(abstract_parts)

        topic_terms = [
            " ".join("".join(term.itertext()).split())
            for term in article.findall(".//MeshHeading/DescriptorName")
        ]

        topic_terms.extend(
            " ".join("".join(term.itertext()).split())
            for term in article.findall(".//Keyword")
        )

        publication_types = [
            " ".join("".join(item.itertext()).split())
            for item in article.findall(".//PublicationType")
        ]

        language = (
            article.findtext(".//Language") or "eng"
        ).strip().lower()

        if (
            not pmid.isdigit()
            or not title
            or len(abstract) < 80
            or language not in {"eng", "en"}
        ):
            continue

        date_parts = [
            article.findtext(".//PubDate/Year"),
            article.findtext(".//PubDate/Month"),
            article.findtext(".//PubDate/Day"),
        ]

        published = "-".join(
            part for part in date_parts if part
        )

        date_value = ""

        if date_parts[0]:
            try:
                month = date_parts[1] or "01"

                if not month.isdigit():
                    month = {
                        "jan": "01", "feb": "02", "mar": "03",
                        "apr": "04", "may": "05", "jun": "06",
                        "jul": "07", "aug": "08", "sep": "09",
                        "oct": "10", "nov": "11", "dec": "12",
                    }.get(month[:3].lower(), "01")

                date_value = date(
                    int(date_parts[0]),
                    int(month),
                    int(date_parts[2] or "01"),
                ).isoformat()

            except (TypeError, ValueError):
                date_value = ""

        record_text = normalize_text(
            f"{title}\n{abstract}"
        )[:100_000]

        rows.append({
            "title": title[:500],
            "url": f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/",
            "text": record_text,
            "language": "en",
            "updated": date_value,
            "publication_date": published[:64],
            "source_type": "research_abstract",
            "external_id": pmid,
            "section_labels": section_labels,
            "topic_terms": topic_terms[:50],
            "publication_types": publication_types[:20],
        })

    return rows


async def _ncbi_request(
    client: httpx.AsyncClient,
    path: str,
    params: dict,
) -> bytes:
    global _ncbi_last_request

    url = f"{PUBMED_API}/{path}"

    if urlparse(url).hostname != NCBI_HOST or not url.startswith("https://"):
        raise ValueError("source_endpoint_invalid")

    async with _ncbi_request_lock:
        delay = 0.34 - (
            time.monotonic() - _ncbi_last_request
        )

        if delay > 0:
            await asyncio.sleep(delay)

        try:
            async with client.stream(
                "GET",
                url,
                params=params,
            ) as response:
                response.raise_for_status()
                body = await _read_limited_response(response)

        finally:
            _ncbi_last_request = time.monotonic()

    return body


async def fetch_pubmed(
    client: httpx.AsyncClient,
    query: str,
) -> list[dict[str, str]]:
    if len(query) > 160 or any(ord(ch) < 32 for ch in query):
        raise ValueError("source_query_invalid")

    search = await _ncbi_request(
        client,
        "esearch.fcgi",
        {
            "db": "pubmed",
            "term": query,
            "retmax": PUBMED_MAX_RECORDS,
            "retmode": "json",
            "tool": "MEDI",
            "email": settings.AI_NCBI_CONTACT_EMAIL,
        },
    )

    try:
        import json

        payload = json.loads(search)
        identifiers = payload["esearchresult"]["idlist"]

    except (ValueError, KeyError, TypeError) as exc:
        raise ValueError("invalid_source_payload") from exc

    ids = [
        str(value)
        for value in identifiers
        if str(value).isdigit()
    ][:PUBMED_MAX_RECORDS]

    if not ids:
        return []

    body = await _ncbi_request(
        client,
        "efetch.fcgi",
        {
            "db": "pubmed",
            "id": ",".join(ids),
            "retmode": "xml",
            "tool": "MEDI",
            "email": settings.AI_NCBI_CONTACT_EMAIL,
        },
    )

    return _parse_pubmed_xml(body)


async def sync_pubmed(
    db: AsyncSession,
    *,
    client: httpx.AsyncClient | None = None,
) -> dict[str, int]:
    if not PUBMED_ACQUISITION_ENABLED:
        return {
            "seen": 0,
            "created": 0,
            "unchanged": 0,
            "metadata_updated": 0,
            "out_of_order": 0,
            "skipped": 1,
            "disabled": 1,
        }

    if not re.fullmatch(
        r"[^@\s]+@[^@\s]+\.[^@\s]+",
        settings.AI_NCBI_CONTACT_EMAIL or "",
    ):
        raise RuntimeError("ncbi_contact_email_not_configured")

    now = datetime.now(timezone.utc)

    source_id = await _ensure_source_and_attempt(
        db,
        now,
        name=PUBMED_SOURCE_NAME,
        source_url=PUBMED_SOURCE_URL,
        publisher=(
            "U.S. National Library of Medicine, "
            "National Center for Biotechnology Information"
        ),
        source_reference=(
            "PubMed records retrieved through official NCBI E-utilities; "
            "see https://www.ncbi.nlm.nih.gov/home/about/policies/"
        ),
    )

    if source_id is None:
        return {
            "seen": 0,
            "created": 0,
            "unchanged": 0,
            "metadata_updated": 0,
            "out_of_order": 0,
            "skipped": 1,
        }

    owns_client = client is None

    client = client or httpx.AsyncClient(
        timeout=settings.AI_KNOWLEDGE_SYNC_TIMEOUT_SECONDS,
        follow_redirects=False,
        headers={"User-Agent": "MEDI-Knowledge-Sync/1.0"},
    )

    try:
        records_by_url: dict[str, dict[str, str]] = {}

        for query in PUBMED_QUERIES:
            for record in await fetch_pubmed(client, query):
                records_by_url[record["url"]] = record

        return await _apply_records(
            db,
            source_id,
            list(records_by_url.values()),
            now,
        )

    except Exception:
        await _record_failure(
            db,
            source_id,
            datetime.now(timezone.utc),
        )
        raise

    finally:
        if owns_client:
            await client.aclose()
