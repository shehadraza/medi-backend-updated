
from __future__ import annotations

import re
from typing import Any

from app.modules.prescriptions.schemas import (
    ExtractedMedicine,
    PrescriptionExtractionResult,
)


MEDICINE_PATTERN = re.compile(
    r"^\s*([A-Za-z][A-Za-z0-9\- ]{1,80}?)"
    r"\s+(\d+(?:\.\d+)?\s*(?:mg|mcg|g|ml|iu|%))"
    r"(?:\s+(tablet|tablets|capsule|capsules|syrup|injection|"
    r"drop|drops|cream|ointment))?\s*$",
    re.IGNORECASE,
)

FREQUENCY_PATTERNS = [
    (
        re.compile(r"\b(once|1 time)\s+(daily|a day)\b", re.I),
        "Once daily",
    ),
    (
        re.compile(r"\b(twice|2 times)\s+(daily|a day)\b", re.I),
        "Twice daily",
    ),
    (
        re.compile(r"\b(thrice|3 times)\s+(daily|a day)\b", re.I),
        "Three times daily",
    ),
    (
        re.compile(r"\b(once|1 time)\s+daily\b", re.I),
        "Once daily",
    ),
    (
        re.compile(r"\b(once|1 time)\s+weekly\b", re.I),
        "Once weekly",
    ),
]

FOOD_PATTERNS = [
    (
        re.compile(r"\b(before food|before meals)\b", re.I),
        "Before food",
    ),
    (
        re.compile(r"\b(after food|after meals)\b", re.I),
        "After food",
    ),
    (
        re.compile(r"\b(with food|with meals)\b", re.I),
        "With food",
    ),
]


def find_frequency(text: str) -> str | None:
    for pattern, value in FREQUENCY_PATTERNS:
        if pattern.search(text):
            return value

    # Preserve the original instruction if it resembles a frequency,
    # but do not interpret ambiguous shorthand.
    return None


def find_duration(text: str) -> str | None:
    patterns = [
        r"\bfor\s+(\d+\s*(?:days?|weeks?|months?))\b",
        r"\bduration\s*:\s*(\d+\s*(?:days?|weeks?|months?))\b",
    ]

    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)

        if match:
            return match.group(1).strip()

    return None


def find_food_instruction(text: str) -> str | None:
    for pattern, value in FOOD_PATTERNS:
        if pattern.search(text):
            return value

    return None


def extract_prescription_medicines(
    prescription_id: str,
    ocr_result: dict[str, Any],
) -> PrescriptionExtractionResult:

    full_text = str(ocr_result.get("full_text") or "")

    if not full_text.strip():
        return PrescriptionExtractionResult(
            prescription_id=prescription_id,
            extraction_status="no_medicines_detected",
            medicines=[],
            warnings=["No readable OCR text was available."],
            requires_user_verification=True,
        )

    lines = [
        line.strip()
        for line in full_text.splitlines()
        if line.strip()
    ]

    medicines: list[ExtractedMedicine] = []
    warnings: list[str] = []

    current_medicine: dict[str, Any] | None = None
    current_lines: list[str] = []

    def save_current() -> None:
        nonlocal current_medicine, current_lines

        if current_medicine is None:
            return

        context = " ".join(current_lines)

        current_medicine["frequency"] = find_frequency(context)
        current_medicine["duration"] = find_duration(context)
        current_medicine["food_instruction"] = (
            find_food_instruction(context)
        )
        current_medicine["additional_instructions"] = (
            context[:1000] if context else None
        )
        current_medicine["source_text"] = (
            "\n".join(current_lines)[:2000]
        )

        medicines.append(
            ExtractedMedicine(**current_medicine)
        )

        current_medicine = None
        current_lines = []

    for line in lines:
        match = MEDICINE_PATTERN.match(line)

        if match:
            save_current()

            name = match.group(1).strip()
            strength = match.group(2).strip()
            form = match.group(3)

            current_medicine = {
                "medicine_name": name,
                "generic_name": None,
                "brand_name": None,
                "strength": strength,
                "dosage_form": form.lower() if form else None,
                "dose": None,
                "frequency": None,
                "duration": None,
                "food_instruction": None,
                "additional_instructions": None,
                "source_text": line,
                "verification_status": "needs_review",
            }

            current_lines = [line]
            continue

        if current_medicine is not None:
            current_lines.append(line)

    save_current()

    if not medicines:
        warnings.append(
            "No medicine name and strength combination could be "
            "reliably identified. Manual review is required."
        )

    if any(
        medicine.frequency is None or medicine.duration is None
        for medicine in medicines
    ):
        warnings.append(
            "Some dosage frequency or duration details were not "
            "clearly identified. Please verify the original prescription."
        )

    return PrescriptionExtractionResult(
        prescription_id=prescription_id,
        extraction_status=(
            "needs_review" if medicines else "no_medicines_detected"
        ),
        medicines=medicines,
        warnings=warnings,
        requires_user_verification=True,
    )
